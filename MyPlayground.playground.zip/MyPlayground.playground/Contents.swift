import UIKit
import CoreLocation
//import SwiftyJSON
var str = "Hello, playground"

let url2:String = "https://free-api.heweather.net/s6/weather/forecast?location=beijing&key=88eab2503fa04723865d1e44f2edc6a6"

func getdata(url:String){
     AF.request(url, method: .get).responseJSON {
        response in
        let weatherJSON = JSON(response.value!)
        analysejson(json:weatherJSON)
    }
}
func analysejson(json:JSON){
    print(json)
    city = json["HeWeather6"][0]["basic"]["location"].stringValue
}
getdata(url:url2)

var tt = "happy ending"
